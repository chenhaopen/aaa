import { createRouter, createWebHashHistory } from 'vue-router'
import index from '../views'
import home from '../views/pages/home.vue'
import login from '../views/pages/login.vue'
import jiashuList from '@/views/pages/jiashu/list'
import jiashuDetail from '@/views/pages/jiashu/formModel'
import jiashuAdd from '@/views/pages/jiashu/formAdd'
import jiashuRegister from '@/views/pages/jiashu/register'
import jiashuCenter from '@/views/pages/jiashu/center'
import liuyanfankuiList from '@/views/pages/liuyanfankui/list'
import liuyanfankuiDetail from '@/views/pages/liuyanfankui/formModel'
import liuyanfankuiAdd from '@/views/pages/liuyanfankui/formAdd'
import meiricanyinList from '@/views/pages/meiricanyin/list'
import meiricanyinDetail from '@/views/pages/meiricanyin/formModel'
import meiricanyinAdd from '@/views/pages/meiricanyin/formAdd'
import chuxingxinxiList from '@/views/pages/chuxingxinxi/list'
import chuxingxinxiDetail from '@/views/pages/chuxingxinxi/formModel'
import chuxingxinxiAdd from '@/views/pages/chuxingxinxi/formAdd'
import laorenxinxiList from '@/views/pages/laorenxinxi/list'
import laorenxinxiDetail from '@/views/pages/laorenxinxi/formModel'
import laorenxinxiAdd from '@/views/pages/laorenxinxi/formAdd'
import jiankangshujuList from '@/views/pages/jiankangshuju/list'
import jiankangshujuDetail from '@/views/pages/jiankangshuju/formModel'
import jiankangshujuAdd from '@/views/pages/jiankangshuju/formAdd'
import yiliaofuwuList from '@/views/pages/yiliaofuwu/list'
import yiliaofuwuDetail from '@/views/pages/yiliaofuwu/formModel'
import yiliaofuwuAdd from '@/views/pages/yiliaofuwu/formAdd'
import chuxingpeihuList from '@/views/pages/chuxingpeihu/list'
import chuxingpeihuDetail from '@/views/pages/chuxingpeihu/formModel'
import chuxingpeihuAdd from '@/views/pages/chuxingpeihu/formAdd'
import waichubaobeiList from '@/views/pages/waichubaobei/list'
import waichubaobeiDetail from '@/views/pages/waichubaobei/formModel'
import waichubaobeiAdd from '@/views/pages/waichubaobei/formAdd'
import xiuxianyuleList from '@/views/pages/xiuxianyule/list'
import xiuxianyuleDetail from '@/views/pages/xiuxianyule/formModel'
import xiuxianyuleAdd from '@/views/pages/xiuxianyule/formAdd'
import yuyueyiliaofuwuList from '@/views/pages/yuyueyiliaofuwu/list'
import yuyueyiliaofuwuDetail from '@/views/pages/yuyueyiliaofuwu/formModel'
import yuyueyiliaofuwuAdd from '@/views/pages/yuyueyiliaofuwu/formAdd'
import yuyuechuxingpeihuList from '@/views/pages/yuyuechuxingpeihu/list'
import yuyuechuxingpeihuDetail from '@/views/pages/yuyuechuxingpeihu/formModel'
import yuyuechuxingpeihuAdd from '@/views/pages/yuyuechuxingpeihu/formAdd'
import laorenruzhudengjiList from '@/views/pages/laorenruzhudengji/list'
import laorenruzhudengjiDetail from '@/views/pages/laorenruzhudengji/formModel'
import laorenruzhudengjiAdd from '@/views/pages/laorenruzhudengji/formAdd'
import fangjianfenpeiList from '@/views/pages/fangjianfenpei/list'
import fangjianfenpeiDetail from '@/views/pages/fangjianfenpei/formModel'
import fangjianfenpeiAdd from '@/views/pages/fangjianfenpei/formAdd'
import hugongList from '@/views/pages/hugong/list'
import hugongDetail from '@/views/pages/hugong/formModel'
import hugongAdd from '@/views/pages/hugong/formAdd'
import paibanxinxiList from '@/views/pages/paibanxinxi/list'
import paibanxinxiDetail from '@/views/pages/paibanxinxi/formModel'
import paibanxinxiAdd from '@/views/pages/paibanxinxi/formAdd'
import binglidanganList from '@/views/pages/binglidangan/list'
import binglidanganDetail from '@/views/pages/binglidangan/formModel'
import binglidanganAdd from '@/views/pages/binglidangan/formAdd'
import yaopinxinxiList from '@/views/pages/yaopinxinxi/list'
import yaopinxinxiDetail from '@/views/pages/yaopinxinxi/formModel'
import yaopinxinxiAdd from '@/views/pages/yaopinxinxi/formAdd'

const routes = [{
		path: '/',
		redirect: '/index/home'
	},
	{
		path: '/index',
		component: index,
		children: [{
			path: 'home',
			component: home
		}
		, {
			path: 'jiashuList',
			component: jiashuList
		}, {
			path: 'jiashuDetail',
			component: jiashuDetail
		}, {
			path: 'jiashuAdd',
			component: jiashuAdd
		}
		, {
			path: 'jiashuCenter',
			component: jiashuCenter
		}
		, {
			path: 'liuyanfankuiList',
			component: liuyanfankuiList
		}, {
			path: 'liuyanfankuiDetail',
			component: liuyanfankuiDetail
		}, {
			path: 'liuyanfankuiAdd',
			component: liuyanfankuiAdd
		}
		, {
			path: 'meiricanyinList',
			component: meiricanyinList
		}, {
			path: 'meiricanyinDetail',
			component: meiricanyinDetail
		}, {
			path: 'meiricanyinAdd',
			component: meiricanyinAdd
		}
		, {
			path: 'chuxingxinxiList',
			component: chuxingxinxiList
		}, {
			path: 'chuxingxinxiDetail',
			component: chuxingxinxiDetail
		}, {
			path: 'chuxingxinxiAdd',
			component: chuxingxinxiAdd
		}
		, {
			path: 'laorenxinxiList',
			component: laorenxinxiList
		}, {
			path: 'laorenxinxiDetail',
			component: laorenxinxiDetail
		}, {
			path: 'laorenxinxiAdd',
			component: laorenxinxiAdd
		}
		, {
			path: 'jiankangshujuList',
			component: jiankangshujuList
		}, {
			path: 'jiankangshujuDetail',
			component: jiankangshujuDetail
		}, {
			path: 'jiankangshujuAdd',
			component: jiankangshujuAdd
		}
		, {
			path: 'yiliaofuwuList',
			component: yiliaofuwuList
		}, {
			path: 'yiliaofuwuDetail',
			component: yiliaofuwuDetail
		}, {
			path: 'yiliaofuwuAdd',
			component: yiliaofuwuAdd
		}
		, {
			path: 'chuxingpeihuList',
			component: chuxingpeihuList
		}, {
			path: 'chuxingpeihuDetail',
			component: chuxingpeihuDetail
		}, {
			path: 'chuxingpeihuAdd',
			component: chuxingpeihuAdd
		}
		, {
			path: 'waichubaobeiList',
			component: waichubaobeiList
		}, {
			path: 'waichubaobeiDetail',
			component: waichubaobeiDetail
		}, {
			path: 'waichubaobeiAdd',
			component: waichubaobeiAdd
		}
		, {
			path: 'xiuxianyuleList',
			component: xiuxianyuleList
		}, {
			path: 'xiuxianyuleDetail',
			component: xiuxianyuleDetail
		}, {
			path: 'xiuxianyuleAdd',
			component: xiuxianyuleAdd
		}
		, {
			path: 'yuyueyiliaofuwuList',
			component: yuyueyiliaofuwuList
		}, {
			path: 'yuyueyiliaofuwuDetail',
			component: yuyueyiliaofuwuDetail
		}, {
			path: 'yuyueyiliaofuwuAdd',
			component: yuyueyiliaofuwuAdd
		}
		, {
			path: 'yuyuechuxingpeihuList',
			component: yuyuechuxingpeihuList
		}, {
			path: 'yuyuechuxingpeihuDetail',
			component: yuyuechuxingpeihuDetail
		}, {
			path: 'yuyuechuxingpeihuAdd',
			component: yuyuechuxingpeihuAdd
		}
		, {
			path: 'laorenruzhudengjiList',
			component: laorenruzhudengjiList
		}, {
			path: 'laorenruzhudengjiDetail',
			component: laorenruzhudengjiDetail
		}, {
			path: 'laorenruzhudengjiAdd',
			component: laorenruzhudengjiAdd
		}
		, {
			path: 'fangjianfenpeiList',
			component: fangjianfenpeiList
		}, {
			path: 'fangjianfenpeiDetail',
			component: fangjianfenpeiDetail
		}, {
			path: 'fangjianfenpeiAdd',
			component: fangjianfenpeiAdd
		}
		, {
			path: 'hugongList',
			component: hugongList
		}, {
			path: 'hugongDetail',
			component: hugongDetail
		}, {
			path: 'hugongAdd',
			component: hugongAdd
		}
		, {
			path: 'paibanxinxiList',
			component: paibanxinxiList
		}, {
			path: 'paibanxinxiDetail',
			component: paibanxinxiDetail
		}, {
			path: 'paibanxinxiAdd',
			component: paibanxinxiAdd
		}
		, {
			path: 'binglidanganList',
			component: binglidanganList
		}, {
			path: 'binglidanganDetail',
			component: binglidanganDetail
		}, {
			path: 'binglidanganAdd',
			component: binglidanganAdd
		}
		, {
			path: 'yaopinxinxiList',
			component: yaopinxinxiList
		}, {
			path: 'yaopinxinxiDetail',
			component: yaopinxinxiDetail
		}, {
			path: 'yaopinxinxiAdd',
			component: yaopinxinxiAdd
		}
		]
	},
	{
		path: '/login',
		component: login
	}
	,{
		path: '/jiashuRegister',
		component: jiashuRegister
	}
]

const router = createRouter({
  history: createWebHashHistory(process.env.BASE_URL),
  routes
})

export default router
