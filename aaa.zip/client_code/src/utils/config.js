const config = {
    get() {
        return {
            url : process.env.VUE_APP_BASE_API_URL + process.env.VUE_APP_BASE_API + '/',
            name: process.env.VUE_APP_BASE_API,
			menuList:[
				{
					name: '休闲娱乐管理',
					icon: '${frontMenu.fontClass}',
					child:[
						{
							name:'休闲娱乐',
							url:'/index/xiuxianyuleList'
						},
					]
				},
				{
					name: '预约服务',
					icon: '${frontMenu.fontClass}',
					child:[
						{
							name:'医疗服务',
							url:'/index/yiliaofuwuList'
						},
						{
							name:'出行陪护',
							url:'/index/chuxingpeihuList'
						},
					]
				},
				{
					name: '留言反馈管理',
					icon: '${frontMenu.fontClass}',
					child:[
						{
							name:'留言反馈',
							url:'/index/liuyanfankuiList'
						},
					]
				},
			]
        }
    },
    getProjectName(){
        return {
            projectName: "基于vue+springboot养老管理系统"
        } 
    }
}
export default config
