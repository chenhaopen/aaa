package com.cl.service.impl;

import org.springframework.stereotype.Service;
import java.util.Map;
import java.util.List;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.cl.utils.PageUtils;
import com.cl.utils.Query;


import com.cl.dao.ChuxingxinxiDao;
import com.cl.entity.ChuxingxinxiEntity;
import com.cl.service.ChuxingxinxiService;
import com.cl.entity.view.ChuxingxinxiView;

@Service("chuxingxinxiService")
public class ChuxingxinxiServiceImpl extends ServiceImpl<ChuxingxinxiDao, ChuxingxinxiEntity> implements ChuxingxinxiService {
	
	
    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        Page<ChuxingxinxiEntity> page = this.selectPage(
                new Query<ChuxingxinxiEntity>(params).getPage(),
                new EntityWrapper<ChuxingxinxiEntity>()
        );
        return new PageUtils(page);
    }
    
    @Override
	public PageUtils queryPage(Map<String, Object> params, Wrapper<ChuxingxinxiEntity> wrapper) {
		  Page<ChuxingxinxiView> page =new Query<ChuxingxinxiView>(params).getPage();
	        page.setRecords(baseMapper.selectListView(page,wrapper));
	    	PageUtils pageUtil = new PageUtils(page);
	    	return pageUtil;
 	}
    
	@Override
	public List<ChuxingxinxiView> selectListView(Wrapper<ChuxingxinxiEntity> wrapper) {
		return baseMapper.selectListView(wrapper);
	}

	@Override
	public ChuxingxinxiView selectView(Wrapper<ChuxingxinxiEntity> wrapper) {
		return baseMapper.selectView(wrapper);
	}


}
