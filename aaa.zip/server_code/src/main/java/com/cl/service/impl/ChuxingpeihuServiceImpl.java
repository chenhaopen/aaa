package com.cl.service.impl;

import org.springframework.stereotype.Service;
import java.util.Map;
import java.util.List;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.cl.utils.PageUtils;
import com.cl.utils.Query;


import com.cl.dao.ChuxingpeihuDao;
import com.cl.entity.ChuxingpeihuEntity;
import com.cl.service.ChuxingpeihuService;
import com.cl.entity.view.ChuxingpeihuView;

@Service("chuxingpeihuService")
public class ChuxingpeihuServiceImpl extends ServiceImpl<ChuxingpeihuDao, ChuxingpeihuEntity> implements ChuxingpeihuService {
	
	
    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        Page<ChuxingpeihuEntity> page = this.selectPage(
                new Query<ChuxingpeihuEntity>(params).getPage(),
                new EntityWrapper<ChuxingpeihuEntity>()
        );
        return new PageUtils(page);
    }
    
    @Override
	public PageUtils queryPage(Map<String, Object> params, Wrapper<ChuxingpeihuEntity> wrapper) {
		  Page<ChuxingpeihuView> page =new Query<ChuxingpeihuView>(params).getPage();
	        page.setRecords(baseMapper.selectListView(page,wrapper));
	    	PageUtils pageUtil = new PageUtils(page);
	    	return pageUtil;
 	}
    
	@Override
	public List<ChuxingpeihuView> selectListView(Wrapper<ChuxingpeihuEntity> wrapper) {
		return baseMapper.selectListView(wrapper);
	}

	@Override
	public ChuxingpeihuView selectView(Wrapper<ChuxingpeihuEntity> wrapper) {
		return baseMapper.selectView(wrapper);
	}


}
