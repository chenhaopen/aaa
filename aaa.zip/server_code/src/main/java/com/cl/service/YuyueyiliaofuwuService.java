package com.cl.service;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.IService;
import com.cl.utils.PageUtils;
import com.cl.entity.YuyueyiliaofuwuEntity;
import java.util.List;
import java.util.Map;
import org.apache.ibatis.annotations.Param;
import com.cl.entity.view.YuyueyiliaofuwuView;


/**
 * 预约医疗服务
 *
 * @author 
 * @email 
 * @date 2024-03-16 22:07:08
 */
public interface YuyueyiliaofuwuService extends IService<YuyueyiliaofuwuEntity> {

    PageUtils queryPage(Map<String, Object> params);
    
   	List<YuyueyiliaofuwuView> selectListView(Wrapper<YuyueyiliaofuwuEntity> wrapper);
   	
   	YuyueyiliaofuwuView selectView(@Param("ew") Wrapper<YuyueyiliaofuwuEntity> wrapper);
   	
   	PageUtils queryPage(Map<String, Object> params,Wrapper<YuyueyiliaofuwuEntity> wrapper);
   	

}

