package com.cl.service.impl;

import org.springframework.stereotype.Service;
import java.util.Map;
import java.util.List;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.cl.utils.PageUtils;
import com.cl.utils.Query;


import com.cl.dao.FangjianfenpeiDao;
import com.cl.entity.FangjianfenpeiEntity;
import com.cl.service.FangjianfenpeiService;
import com.cl.entity.view.FangjianfenpeiView;

@Service("fangjianfenpeiService")
public class FangjianfenpeiServiceImpl extends ServiceImpl<FangjianfenpeiDao, FangjianfenpeiEntity> implements FangjianfenpeiService {
	
	
    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        Page<FangjianfenpeiEntity> page = this.selectPage(
                new Query<FangjianfenpeiEntity>(params).getPage(),
                new EntityWrapper<FangjianfenpeiEntity>()
        );
        return new PageUtils(page);
    }
    
    @Override
	public PageUtils queryPage(Map<String, Object> params, Wrapper<FangjianfenpeiEntity> wrapper) {
		  Page<FangjianfenpeiView> page =new Query<FangjianfenpeiView>(params).getPage();
	        page.setRecords(baseMapper.selectListView(page,wrapper));
	    	PageUtils pageUtil = new PageUtils(page);
	    	return pageUtil;
 	}
    
	@Override
	public List<FangjianfenpeiView> selectListView(Wrapper<FangjianfenpeiEntity> wrapper) {
		return baseMapper.selectListView(wrapper);
	}

	@Override
	public FangjianfenpeiView selectView(Wrapper<FangjianfenpeiEntity> wrapper) {
		return baseMapper.selectView(wrapper);
	}


}
