package com.cl.service;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.IService;
import com.cl.utils.PageUtils;
import com.cl.entity.XiuxianyuleEntity;
import java.util.List;
import java.util.Map;
import org.apache.ibatis.annotations.Param;
import com.cl.entity.view.XiuxianyuleView;


/**
 * 休闲娱乐
 *
 * @author 
 * @email 
 * @date 2024-03-16 22:07:08
 */
public interface XiuxianyuleService extends IService<XiuxianyuleEntity> {

    PageUtils queryPage(Map<String, Object> params);
    
   	List<XiuxianyuleView> selectListView(Wrapper<XiuxianyuleEntity> wrapper);
   	
   	XiuxianyuleView selectView(@Param("ew") Wrapper<XiuxianyuleEntity> wrapper);
   	
   	PageUtils queryPage(Map<String, Object> params,Wrapper<XiuxianyuleEntity> wrapper);
   	

}

