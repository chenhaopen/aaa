package com.cl.service.impl;

import org.springframework.stereotype.Service;
import java.util.Map;
import java.util.List;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.cl.utils.PageUtils;
import com.cl.utils.Query;


import com.cl.dao.WaichubaobeiDao;
import com.cl.entity.WaichubaobeiEntity;
import com.cl.service.WaichubaobeiService;
import com.cl.entity.view.WaichubaobeiView;

@Service("waichubaobeiService")
public class WaichubaobeiServiceImpl extends ServiceImpl<WaichubaobeiDao, WaichubaobeiEntity> implements WaichubaobeiService {
	
	
    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        Page<WaichubaobeiEntity> page = this.selectPage(
                new Query<WaichubaobeiEntity>(params).getPage(),
                new EntityWrapper<WaichubaobeiEntity>()
        );
        return new PageUtils(page);
    }
    
    @Override
	public PageUtils queryPage(Map<String, Object> params, Wrapper<WaichubaobeiEntity> wrapper) {
		  Page<WaichubaobeiView> page =new Query<WaichubaobeiView>(params).getPage();
	        page.setRecords(baseMapper.selectListView(page,wrapper));
	    	PageUtils pageUtil = new PageUtils(page);
	    	return pageUtil;
 	}
    
	@Override
	public List<WaichubaobeiView> selectListView(Wrapper<WaichubaobeiEntity> wrapper) {
		return baseMapper.selectListView(wrapper);
	}

	@Override
	public WaichubaobeiView selectView(Wrapper<WaichubaobeiEntity> wrapper) {
		return baseMapper.selectView(wrapper);
	}


}
