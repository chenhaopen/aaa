package com.cl.service.impl;

import org.springframework.stereotype.Service;
import java.util.Map;
import java.util.List;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.cl.utils.PageUtils;
import com.cl.utils.Query;


import com.cl.dao.JiashuDao;
import com.cl.entity.JiashuEntity;
import com.cl.service.JiashuService;
import com.cl.entity.view.JiashuView;

@Service("jiashuService")
public class JiashuServiceImpl extends ServiceImpl<JiashuDao, JiashuEntity> implements JiashuService {
	
	
    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        Page<JiashuEntity> page = this.selectPage(
                new Query<JiashuEntity>(params).getPage(),
                new EntityWrapper<JiashuEntity>()
        );
        return new PageUtils(page);
    }
    
    @Override
	public PageUtils queryPage(Map<String, Object> params, Wrapper<JiashuEntity> wrapper) {
		  Page<JiashuView> page =new Query<JiashuView>(params).getPage();
	        page.setRecords(baseMapper.selectListView(page,wrapper));
	    	PageUtils pageUtil = new PageUtils(page);
	    	return pageUtil;
 	}
    
	@Override
	public List<JiashuView> selectListView(Wrapper<JiashuEntity> wrapper) {
		return baseMapper.selectListView(wrapper);
	}

	@Override
	public JiashuView selectView(Wrapper<JiashuEntity> wrapper) {
		return baseMapper.selectView(wrapper);
	}


}
