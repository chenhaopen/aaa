package com.cl.service.impl;

import org.springframework.stereotype.Service;
import java.util.Map;
import java.util.List;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.cl.utils.PageUtils;
import com.cl.utils.Query;


import com.cl.dao.YuyuechuxingpeihuDao;
import com.cl.entity.YuyuechuxingpeihuEntity;
import com.cl.service.YuyuechuxingpeihuService;
import com.cl.entity.view.YuyuechuxingpeihuView;

@Service("yuyuechuxingpeihuService")
public class YuyuechuxingpeihuServiceImpl extends ServiceImpl<YuyuechuxingpeihuDao, YuyuechuxingpeihuEntity> implements YuyuechuxingpeihuService {
	
	
    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        Page<YuyuechuxingpeihuEntity> page = this.selectPage(
                new Query<YuyuechuxingpeihuEntity>(params).getPage(),
                new EntityWrapper<YuyuechuxingpeihuEntity>()
        );
        return new PageUtils(page);
    }
    
    @Override
	public PageUtils queryPage(Map<String, Object> params, Wrapper<YuyuechuxingpeihuEntity> wrapper) {
		  Page<YuyuechuxingpeihuView> page =new Query<YuyuechuxingpeihuView>(params).getPage();
	        page.setRecords(baseMapper.selectListView(page,wrapper));
	    	PageUtils pageUtil = new PageUtils(page);
	    	return pageUtil;
 	}
    
	@Override
	public List<YuyuechuxingpeihuView> selectListView(Wrapper<YuyuechuxingpeihuEntity> wrapper) {
		return baseMapper.selectListView(wrapper);
	}

	@Override
	public YuyuechuxingpeihuView selectView(Wrapper<YuyuechuxingpeihuEntity> wrapper) {
		return baseMapper.selectView(wrapper);
	}


}
