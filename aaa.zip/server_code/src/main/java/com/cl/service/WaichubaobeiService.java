package com.cl.service;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.IService;
import com.cl.utils.PageUtils;
import com.cl.entity.WaichubaobeiEntity;
import java.util.List;
import java.util.Map;
import org.apache.ibatis.annotations.Param;
import com.cl.entity.view.WaichubaobeiView;


/**
 * 外出报备
 *
 * @author 
 * @email 
 * @date 2024-03-16 22:07:08
 */
public interface WaichubaobeiService extends IService<WaichubaobeiEntity> {

    PageUtils queryPage(Map<String, Object> params);
    
   	List<WaichubaobeiView> selectListView(Wrapper<WaichubaobeiEntity> wrapper);
   	
   	WaichubaobeiView selectView(@Param("ew") Wrapper<WaichubaobeiEntity> wrapper);
   	
   	PageUtils queryPage(Map<String, Object> params,Wrapper<WaichubaobeiEntity> wrapper);
   	

}

