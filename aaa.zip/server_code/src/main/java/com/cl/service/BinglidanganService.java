package com.cl.service;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.IService;
import com.cl.utils.PageUtils;
import com.cl.entity.BinglidanganEntity;
import java.util.List;
import java.util.Map;
import org.apache.ibatis.annotations.Param;
import com.cl.entity.view.BinglidanganView;


/**
 * 病例档案
 *
 * @author 
 * @email 
 * @date 2024-03-16 22:07:09
 */
public interface BinglidanganService extends IService<BinglidanganEntity> {

    PageUtils queryPage(Map<String, Object> params);
    
   	List<BinglidanganView> selectListView(Wrapper<BinglidanganEntity> wrapper);
   	
   	BinglidanganView selectView(@Param("ew") Wrapper<BinglidanganEntity> wrapper);
   	
   	PageUtils queryPage(Map<String, Object> params,Wrapper<BinglidanganEntity> wrapper);
   	

}

