package com.cl.service;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.IService;
import com.cl.utils.PageUtils;
import com.cl.entity.YuyuechuxingpeihuEntity;
import java.util.List;
import java.util.Map;
import org.apache.ibatis.annotations.Param;
import com.cl.entity.view.YuyuechuxingpeihuView;


/**
 * 预约出行陪护
 *
 * @author 
 * @email 
 * @date 2024-03-16 22:07:09
 */
public interface YuyuechuxingpeihuService extends IService<YuyuechuxingpeihuEntity> {

    PageUtils queryPage(Map<String, Object> params);
    
   	List<YuyuechuxingpeihuView> selectListView(Wrapper<YuyuechuxingpeihuEntity> wrapper);
   	
   	YuyuechuxingpeihuView selectView(@Param("ew") Wrapper<YuyuechuxingpeihuEntity> wrapper);
   	
   	PageUtils queryPage(Map<String, Object> params,Wrapper<YuyuechuxingpeihuEntity> wrapper);
   	

}

