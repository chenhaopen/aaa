package com.cl.service.impl;

import org.springframework.stereotype.Service;
import java.util.Map;
import java.util.List;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.cl.utils.PageUtils;
import com.cl.utils.Query;


import com.cl.dao.YuyueyiliaofuwuDao;
import com.cl.entity.YuyueyiliaofuwuEntity;
import com.cl.service.YuyueyiliaofuwuService;
import com.cl.entity.view.YuyueyiliaofuwuView;

@Service("yuyueyiliaofuwuService")
public class YuyueyiliaofuwuServiceImpl extends ServiceImpl<YuyueyiliaofuwuDao, YuyueyiliaofuwuEntity> implements YuyueyiliaofuwuService {
	
	
    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        Page<YuyueyiliaofuwuEntity> page = this.selectPage(
                new Query<YuyueyiliaofuwuEntity>(params).getPage(),
                new EntityWrapper<YuyueyiliaofuwuEntity>()
        );
        return new PageUtils(page);
    }
    
    @Override
	public PageUtils queryPage(Map<String, Object> params, Wrapper<YuyueyiliaofuwuEntity> wrapper) {
		  Page<YuyueyiliaofuwuView> page =new Query<YuyueyiliaofuwuView>(params).getPage();
	        page.setRecords(baseMapper.selectListView(page,wrapper));
	    	PageUtils pageUtil = new PageUtils(page);
	    	return pageUtil;
 	}
    
	@Override
	public List<YuyueyiliaofuwuView> selectListView(Wrapper<YuyueyiliaofuwuEntity> wrapper) {
		return baseMapper.selectListView(wrapper);
	}

	@Override
	public YuyueyiliaofuwuView selectView(Wrapper<YuyueyiliaofuwuEntity> wrapper) {
		return baseMapper.selectView(wrapper);
	}


}
