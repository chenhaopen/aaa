package com.cl.service.impl;

import org.springframework.stereotype.Service;
import java.util.Map;
import java.util.List;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.cl.utils.PageUtils;
import com.cl.utils.Query;


import com.cl.dao.LaorenruzhudengjiDao;
import com.cl.entity.LaorenruzhudengjiEntity;
import com.cl.service.LaorenruzhudengjiService;
import com.cl.entity.view.LaorenruzhudengjiView;

@Service("laorenruzhudengjiService")
public class LaorenruzhudengjiServiceImpl extends ServiceImpl<LaorenruzhudengjiDao, LaorenruzhudengjiEntity> implements LaorenruzhudengjiService {
	
	
    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        Page<LaorenruzhudengjiEntity> page = this.selectPage(
                new Query<LaorenruzhudengjiEntity>(params).getPage(),
                new EntityWrapper<LaorenruzhudengjiEntity>()
        );
        return new PageUtils(page);
    }
    
    @Override
	public PageUtils queryPage(Map<String, Object> params, Wrapper<LaorenruzhudengjiEntity> wrapper) {
		  Page<LaorenruzhudengjiView> page =new Query<LaorenruzhudengjiView>(params).getPage();
	        page.setRecords(baseMapper.selectListView(page,wrapper));
	    	PageUtils pageUtil = new PageUtils(page);
	    	return pageUtil;
 	}
    
	@Override
	public List<LaorenruzhudengjiView> selectListView(Wrapper<LaorenruzhudengjiEntity> wrapper) {
		return baseMapper.selectListView(wrapper);
	}

	@Override
	public LaorenruzhudengjiView selectView(Wrapper<LaorenruzhudengjiEntity> wrapper) {
		return baseMapper.selectView(wrapper);
	}


}
