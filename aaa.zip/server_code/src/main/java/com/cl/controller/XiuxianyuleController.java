package com.cl.controller;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Map;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Date;
import java.util.List;
import javax.servlet.http.HttpServletRequest;

import com.cl.utils.ValidatorUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.cl.annotation.IgnoreAuth;

import com.cl.entity.XiuxianyuleEntity;
import com.cl.entity.view.XiuxianyuleView;

import com.cl.service.XiuxianyuleService;
import com.cl.service.TokenService;
import com.cl.utils.PageUtils;
import com.cl.utils.R;
import com.cl.utils.MPUtil;
import com.cl.utils.CommonUtil;
import java.io.IOException;

/**
 * 休闲娱乐
 * 后端接口
 * @author 
 * @email 
 * @date 2024-03-16 22:07:08
 */
@RestController
@RequestMapping("/xiuxianyule")
public class XiuxianyuleController {
    @Autowired
    private XiuxianyuleService xiuxianyuleService;



    


    /**
     * 后端列表
     */
    @RequestMapping("/page")
    public R page(@RequestParam Map<String, Object> params,XiuxianyuleEntity xiuxianyule,
		HttpServletRequest request){
        EntityWrapper<XiuxianyuleEntity> ew = new EntityWrapper<XiuxianyuleEntity>();

		PageUtils page = xiuxianyuleService.queryPage(params, MPUtil.sort(MPUtil.between(MPUtil.likeOrEq(ew, xiuxianyule), params), params));

        return R.ok().put("data", page);
    }
    
    /**
     * 前端列表
     */
	@IgnoreAuth
    @RequestMapping("/list")
    public R list(@RequestParam Map<String, Object> params,XiuxianyuleEntity xiuxianyule, 
		HttpServletRequest request){
        EntityWrapper<XiuxianyuleEntity> ew = new EntityWrapper<XiuxianyuleEntity>();

		PageUtils page = xiuxianyuleService.queryPage(params, MPUtil.sort(MPUtil.between(MPUtil.likeOrEq(ew, xiuxianyule), params), params));
        return R.ok().put("data", page);
    }

	/**
     * 列表
     */
    @RequestMapping("/lists")
    public R list( XiuxianyuleEntity xiuxianyule){
       	EntityWrapper<XiuxianyuleEntity> ew = new EntityWrapper<XiuxianyuleEntity>();
      	ew.allEq(MPUtil.allEQMapPre( xiuxianyule, "xiuxianyule")); 
        return R.ok().put("data", xiuxianyuleService.selectListView(ew));
    }

	 /**
     * 查询
     */
    @RequestMapping("/query")
    public R query(XiuxianyuleEntity xiuxianyule){
        EntityWrapper< XiuxianyuleEntity> ew = new EntityWrapper< XiuxianyuleEntity>();
 		ew.allEq(MPUtil.allEQMapPre( xiuxianyule, "xiuxianyule")); 
		XiuxianyuleView xiuxianyuleView =  xiuxianyuleService.selectView(ew);
		return R.ok("查询休闲娱乐成功").put("data", xiuxianyuleView);
    }
	
    /**
     * 后端详情
     */
    @RequestMapping("/info/{id}")
    public R info(@PathVariable("id") Long id){
        XiuxianyuleEntity xiuxianyule = xiuxianyuleService.selectById(id);
		xiuxianyule = xiuxianyuleService.selectView(new EntityWrapper<XiuxianyuleEntity>().eq("id", id));
        return R.ok().put("data", xiuxianyule);
    }

    /**
     * 前端详情
     */
	@IgnoreAuth
    @RequestMapping("/detail/{id}")
    public R detail(@PathVariable("id") Long id){
        XiuxianyuleEntity xiuxianyule = xiuxianyuleService.selectById(id);
		xiuxianyule = xiuxianyuleService.selectView(new EntityWrapper<XiuxianyuleEntity>().eq("id", id));
        return R.ok().put("data", xiuxianyule);
    }
    



    /**
     * 后端保存
     */
    @RequestMapping("/save")
    public R save(@RequestBody XiuxianyuleEntity xiuxianyule, HttpServletRequest request){
    	xiuxianyule.setId(new Date().getTime()+new Double(Math.floor(Math.random()*1000)).longValue());
    	//ValidatorUtils.validateEntity(xiuxianyule);
        xiuxianyuleService.insert(xiuxianyule);
        return R.ok();
    }
    
    /**
     * 前端保存
     */
    @RequestMapping("/add")
    public R add(@RequestBody XiuxianyuleEntity xiuxianyule, HttpServletRequest request){
    	xiuxianyule.setId(new Date().getTime()+new Double(Math.floor(Math.random()*1000)).longValue());
    	//ValidatorUtils.validateEntity(xiuxianyule);
        xiuxianyuleService.insert(xiuxianyule);
        return R.ok();
    }



    /**
     * 修改
     */
    @RequestMapping("/update")
    @Transactional
    public R update(@RequestBody XiuxianyuleEntity xiuxianyule, HttpServletRequest request){
        //ValidatorUtils.validateEntity(xiuxianyule);
        xiuxianyuleService.updateById(xiuxianyule);//全部更新
        return R.ok();
    }



    

    /**
     * 删除
     */
    @RequestMapping("/delete")
    public R delete(@RequestBody Long[] ids){
        xiuxianyuleService.deleteBatchIds(Arrays.asList(ids));
        return R.ok();
    }
    
	








}
