package com.cl.controller;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Map;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Date;
import java.util.List;
import javax.servlet.http.HttpServletRequest;

import com.cl.utils.ValidatorUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.cl.annotation.IgnoreAuth;

import com.cl.entity.FangjianfenpeiEntity;
import com.cl.entity.view.FangjianfenpeiView;

import com.cl.service.FangjianfenpeiService;
import com.cl.service.TokenService;
import com.cl.utils.PageUtils;
import com.cl.utils.R;
import com.cl.utils.MPUtil;
import com.cl.utils.CommonUtil;
import java.io.IOException;

/**
 * 房间分配
 * 后端接口
 * @author 
 * @email 
 * @date 2024-03-16 22:07:09
 */
@RestController
@RequestMapping("/fangjianfenpei")
public class FangjianfenpeiController {
    @Autowired
    private FangjianfenpeiService fangjianfenpeiService;



    


    /**
     * 后端列表
     */
    @RequestMapping("/page")
    public R page(@RequestParam Map<String, Object> params,FangjianfenpeiEntity fangjianfenpei,
		HttpServletRequest request){
		String tableName = request.getSession().getAttribute("tableName").toString();
		if(tableName.equals("jiashu")) {
			fangjianfenpei.setJiashuzhanghao((String)request.getSession().getAttribute("username"));
		}
        EntityWrapper<FangjianfenpeiEntity> ew = new EntityWrapper<FangjianfenpeiEntity>();

		PageUtils page = fangjianfenpeiService.queryPage(params, MPUtil.sort(MPUtil.between(MPUtil.likeOrEq(ew, fangjianfenpei), params), params));

        return R.ok().put("data", page);
    }
    
    /**
     * 前端列表
     */
	@IgnoreAuth
    @RequestMapping("/list")
    public R list(@RequestParam Map<String, Object> params,FangjianfenpeiEntity fangjianfenpei, 
		HttpServletRequest request){
        EntityWrapper<FangjianfenpeiEntity> ew = new EntityWrapper<FangjianfenpeiEntity>();

		PageUtils page = fangjianfenpeiService.queryPage(params, MPUtil.sort(MPUtil.between(MPUtil.likeOrEq(ew, fangjianfenpei), params), params));
        return R.ok().put("data", page);
    }

	/**
     * 列表
     */
    @RequestMapping("/lists")
    public R list( FangjianfenpeiEntity fangjianfenpei){
       	EntityWrapper<FangjianfenpeiEntity> ew = new EntityWrapper<FangjianfenpeiEntity>();
      	ew.allEq(MPUtil.allEQMapPre( fangjianfenpei, "fangjianfenpei")); 
        return R.ok().put("data", fangjianfenpeiService.selectListView(ew));
    }

	 /**
     * 查询
     */
    @RequestMapping("/query")
    public R query(FangjianfenpeiEntity fangjianfenpei){
        EntityWrapper< FangjianfenpeiEntity> ew = new EntityWrapper< FangjianfenpeiEntity>();
 		ew.allEq(MPUtil.allEQMapPre( fangjianfenpei, "fangjianfenpei")); 
		FangjianfenpeiView fangjianfenpeiView =  fangjianfenpeiService.selectView(ew);
		return R.ok("查询房间分配成功").put("data", fangjianfenpeiView);
    }
	
    /**
     * 后端详情
     */
    @RequestMapping("/info/{id}")
    public R info(@PathVariable("id") Long id){
        FangjianfenpeiEntity fangjianfenpei = fangjianfenpeiService.selectById(id);
		fangjianfenpei = fangjianfenpeiService.selectView(new EntityWrapper<FangjianfenpeiEntity>().eq("id", id));
        return R.ok().put("data", fangjianfenpei);
    }

    /**
     * 前端详情
     */
	@IgnoreAuth
    @RequestMapping("/detail/{id}")
    public R detail(@PathVariable("id") Long id){
        FangjianfenpeiEntity fangjianfenpei = fangjianfenpeiService.selectById(id);
		fangjianfenpei = fangjianfenpeiService.selectView(new EntityWrapper<FangjianfenpeiEntity>().eq("id", id));
        return R.ok().put("data", fangjianfenpei);
    }
    



    /**
     * 后端保存
     */
    @RequestMapping("/save")
    public R save(@RequestBody FangjianfenpeiEntity fangjianfenpei, HttpServletRequest request){
    	fangjianfenpei.setId(new Date().getTime()+new Double(Math.floor(Math.random()*1000)).longValue());
    	//ValidatorUtils.validateEntity(fangjianfenpei);
        fangjianfenpeiService.insert(fangjianfenpei);
        return R.ok();
    }
    
    /**
     * 前端保存
     */
    @RequestMapping("/add")
    public R add(@RequestBody FangjianfenpeiEntity fangjianfenpei, HttpServletRequest request){
    	fangjianfenpei.setId(new Date().getTime()+new Double(Math.floor(Math.random()*1000)).longValue());
    	//ValidatorUtils.validateEntity(fangjianfenpei);
        fangjianfenpeiService.insert(fangjianfenpei);
        return R.ok();
    }



    /**
     * 修改
     */
    @RequestMapping("/update")
    @Transactional
    public R update(@RequestBody FangjianfenpeiEntity fangjianfenpei, HttpServletRequest request){
        //ValidatorUtils.validateEntity(fangjianfenpei);
        fangjianfenpeiService.updateById(fangjianfenpei);//全部更新
        return R.ok();
    }



    

    /**
     * 删除
     */
    @RequestMapping("/delete")
    public R delete(@RequestBody Long[] ids){
        fangjianfenpeiService.deleteBatchIds(Arrays.asList(ids));
        return R.ok();
    }
    
	








}
