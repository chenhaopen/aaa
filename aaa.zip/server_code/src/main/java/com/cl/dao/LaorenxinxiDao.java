package com.cl.dao;

import com.cl.entity.LaorenxinxiEntity;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import java.util.List;
import java.util.Map;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.pagination.Pagination;

import org.apache.ibatis.annotations.Param;
import com.cl.entity.view.LaorenxinxiView;


/**
 * 老人信息
 * 
 * @author 
 * @email 
 * @date 2024-03-16 22:07:08
 */
public interface LaorenxinxiDao extends BaseMapper<LaorenxinxiEntity> {
	
	List<LaorenxinxiView> selectListView(@Param("ew") Wrapper<LaorenxinxiEntity> wrapper);

	List<LaorenxinxiView> selectListView(Pagination page,@Param("ew") Wrapper<LaorenxinxiEntity> wrapper);
	
	LaorenxinxiView selectView(@Param("ew") Wrapper<LaorenxinxiEntity> wrapper);
	

}
