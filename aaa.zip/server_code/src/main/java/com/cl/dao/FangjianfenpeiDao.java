package com.cl.dao;

import com.cl.entity.FangjianfenpeiEntity;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import java.util.List;
import java.util.Map;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.pagination.Pagination;

import org.apache.ibatis.annotations.Param;
import com.cl.entity.view.FangjianfenpeiView;


/**
 * 房间分配
 * 
 * @author 
 * @email 
 * @date 2024-03-16 22:07:09
 */
public interface FangjianfenpeiDao extends BaseMapper<FangjianfenpeiEntity> {
	
	List<FangjianfenpeiView> selectListView(@Param("ew") Wrapper<FangjianfenpeiEntity> wrapper);

	List<FangjianfenpeiView> selectListView(Pagination page,@Param("ew") Wrapper<FangjianfenpeiEntity> wrapper);
	
	FangjianfenpeiView selectView(@Param("ew") Wrapper<FangjianfenpeiEntity> wrapper);
	

}
