
package com.cl.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.cl.entity.ConfigEntity;

/**
 * 配置
 */
public interface ConfigDao extends BaseMapper<ConfigEntity> {
	
}
