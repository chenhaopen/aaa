package com.cl.dao;

import com.cl.entity.ChuxingpeihuEntity;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import java.util.List;
import java.util.Map;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.pagination.Pagination;

import org.apache.ibatis.annotations.Param;
import com.cl.entity.view.ChuxingpeihuView;


/**
 * 出行陪护
 * 
 * @author 
 * @email 
 * @date 2024-03-16 22:07:08
 */
public interface ChuxingpeihuDao extends BaseMapper<ChuxingpeihuEntity> {
	
	List<ChuxingpeihuView> selectListView(@Param("ew") Wrapper<ChuxingpeihuEntity> wrapper);

	List<ChuxingpeihuView> selectListView(Pagination page,@Param("ew") Wrapper<ChuxingpeihuEntity> wrapper);
	
	ChuxingpeihuView selectView(@Param("ew") Wrapper<ChuxingpeihuEntity> wrapper);
	

}
