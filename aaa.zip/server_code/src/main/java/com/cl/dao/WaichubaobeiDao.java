package com.cl.dao;

import com.cl.entity.WaichubaobeiEntity;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import java.util.List;
import java.util.Map;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.pagination.Pagination;

import org.apache.ibatis.annotations.Param;
import com.cl.entity.view.WaichubaobeiView;


/**
 * 外出报备
 * 
 * @author 
 * @email 
 * @date 2024-03-16 22:07:08
 */
public interface WaichubaobeiDao extends BaseMapper<WaichubaobeiEntity> {
	
	List<WaichubaobeiView> selectListView(@Param("ew") Wrapper<WaichubaobeiEntity> wrapper);

	List<WaichubaobeiView> selectListView(Pagination page,@Param("ew") Wrapper<WaichubaobeiEntity> wrapper);
	
	WaichubaobeiView selectView(@Param("ew") Wrapper<WaichubaobeiEntity> wrapper);
	

}
