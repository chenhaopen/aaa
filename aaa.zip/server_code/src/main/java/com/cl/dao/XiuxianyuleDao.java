package com.cl.dao;

import com.cl.entity.XiuxianyuleEntity;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import java.util.List;
import java.util.Map;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.pagination.Pagination;

import org.apache.ibatis.annotations.Param;
import com.cl.entity.view.XiuxianyuleView;


/**
 * 休闲娱乐
 * 
 * @author 
 * @email 
 * @date 2024-03-16 22:07:08
 */
public interface XiuxianyuleDao extends BaseMapper<XiuxianyuleEntity> {
	
	List<XiuxianyuleView> selectListView(@Param("ew") Wrapper<XiuxianyuleEntity> wrapper);

	List<XiuxianyuleView> selectListView(Pagination page,@Param("ew") Wrapper<XiuxianyuleEntity> wrapper);
	
	XiuxianyuleView selectView(@Param("ew") Wrapper<XiuxianyuleEntity> wrapper);
	

}
