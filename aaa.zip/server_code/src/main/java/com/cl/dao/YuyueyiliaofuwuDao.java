package com.cl.dao;

import com.cl.entity.YuyueyiliaofuwuEntity;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import java.util.List;
import java.util.Map;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.pagination.Pagination;

import org.apache.ibatis.annotations.Param;
import com.cl.entity.view.YuyueyiliaofuwuView;


/**
 * 预约医疗服务
 * 
 * @author 
 * @email 
 * @date 2024-03-16 22:07:08
 */
public interface YuyueyiliaofuwuDao extends BaseMapper<YuyueyiliaofuwuEntity> {
	
	List<YuyueyiliaofuwuView> selectListView(@Param("ew") Wrapper<YuyueyiliaofuwuEntity> wrapper);

	List<YuyueyiliaofuwuView> selectListView(Pagination page,@Param("ew") Wrapper<YuyueyiliaofuwuEntity> wrapper);
	
	YuyueyiliaofuwuView selectView(@Param("ew") Wrapper<YuyueyiliaofuwuEntity> wrapper);
	

}
