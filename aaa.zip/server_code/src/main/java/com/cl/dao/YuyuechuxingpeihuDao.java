package com.cl.dao;

import com.cl.entity.YuyuechuxingpeihuEntity;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import java.util.List;
import java.util.Map;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.pagination.Pagination;

import org.apache.ibatis.annotations.Param;
import com.cl.entity.view.YuyuechuxingpeihuView;


/**
 * 预约出行陪护
 * 
 * @author 
 * @email 
 * @date 2024-03-16 22:07:09
 */
public interface YuyuechuxingpeihuDao extends BaseMapper<YuyuechuxingpeihuEntity> {
	
	List<YuyuechuxingpeihuView> selectListView(@Param("ew") Wrapper<YuyuechuxingpeihuEntity> wrapper);

	List<YuyuechuxingpeihuView> selectListView(Pagination page,@Param("ew") Wrapper<YuyuechuxingpeihuEntity> wrapper);
	
	YuyuechuxingpeihuView selectView(@Param("ew") Wrapper<YuyuechuxingpeihuEntity> wrapper);
	

}
