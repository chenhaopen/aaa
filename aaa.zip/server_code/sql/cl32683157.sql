-- MySQL dump 10.13  Distrib 5.7.31, for Linux (x86_64)
--
-- Host: localhost    Database: cl32683157
-- ------------------------------------------------------
-- Server version	5.7.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `cl32683157`
--

/*!40000 DROP DATABASE IF EXISTS `cl32683157`*/;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `cl32683157` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;

USE `cl32683157`;

--
-- Table structure for table `binglidangan`
--

DROP TABLE IF EXISTS `binglidangan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `binglidangan` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `binglibianhao` varchar(200) DEFAULT NULL COMMENT '病例编号',
  `laorenxingming` varchar(200) NOT NULL COMMENT '老人姓名',
  `jiashuzhanghao` varchar(200) DEFAULT NULL COMMENT '家属账号',
  `jiashuxingming` varchar(200) DEFAULT NULL COMMENT '家属姓名',
  `xingbie` varchar(200) DEFAULT NULL COMMENT '性别',
  `nianling` varchar(200) DEFAULT NULL COMMENT '年龄',
  `binglixiangqing` longtext NOT NULL COMMENT '病例详情',
  `binglibaogao` longtext COMMENT '病例报告',
  `dengjishijian` datetime DEFAULT NULL COMMENT '登记时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `binglibianhao` (`binglibianhao`)
) ENGINE=InnoDB AUTO_INCREMENT=1710598265714 DEFAULT CHARSET=utf8 COMMENT='病例档案';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `binglidangan`
--

LOCK TABLES `binglidangan` WRITE;
/*!40000 ALTER TABLE `binglidangan` DISABLE KEYS */;
INSERT INTO `binglidangan` VALUES (191,'2024-03-16 14:07:14','1111111111','老人姓名1','家属账号1','家属姓名1','性别1','年龄1','病例详情1','','2024-03-16 22:07:14'),(192,'2024-03-16 14:07:14','2222222222','老人姓名2','家属账号2','家属姓名2','性别2','年龄2','病例详情2','','2024-03-16 22:07:14'),(193,'2024-03-16 14:07:14','3333333333','老人姓名3','家属账号3','家属姓名3','性别3','年龄3','病例详情3','','2024-03-16 22:07:14'),(194,'2024-03-16 14:07:14','4444444444','老人姓名4','家属账号4','家属姓名4','性别4','年龄4','病例详情4','','2024-03-16 22:07:14'),(195,'2024-03-16 14:07:14','5555555555','老人姓名5','家属账号5','家属姓名5','性别5','年龄5','病例详情5','','2024-03-16 22:07:14'),(196,'2024-03-16 14:07:14','6666666666','老人姓名6','家属账号6','家属姓名6','性别6','年龄6','病例详情6','','2024-03-16 22:07:14'),(1710598265713,'2024-03-16 14:11:04','1710598256279','老几','11','李局','男','56','<p>111</p>','file/1710598263067.jpg','2024-03-16 22:10:56');
/*!40000 ALTER TABLE `binglidangan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chuxingpeihu`
--

DROP TABLE IF EXISTS `chuxingpeihu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chuxingpeihu` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `fuwuleixing` varchar(200) DEFAULT NULL COMMENT '服务类型',
  `fuwuneirong` longtext COMMENT '服务内容',
  `fabushijian` date DEFAULT NULL COMMENT '发布时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=107 DEFAULT CHARSET=utf8 COMMENT='出行陪护';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chuxingpeihu`
--

LOCK TABLES `chuxingpeihu` WRITE;
/*!40000 ALTER TABLE `chuxingpeihu` DISABLE KEYS */;
INSERT INTO `chuxingpeihu` VALUES (101,'2024-03-16 14:07:14','服务类型1','服务内容1','2024-03-16'),(102,'2024-03-16 14:07:14','服务类型2','服务内容2','2024-03-16'),(103,'2024-03-16 14:07:14','服务类型3','服务内容3','2024-03-16'),(104,'2024-03-16 14:07:14','服务类型4','服务内容4','2024-03-16'),(105,'2024-03-16 14:07:14','服务类型5','服务内容5','2024-03-16'),(106,'2024-03-16 14:07:14','服务类型6','服务内容6','2024-03-16');
/*!40000 ALTER TABLE `chuxingpeihu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chuxingxinxi`
--

DROP TABLE IF EXISTS `chuxingxinxi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chuxingxinxi` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `chuxingriqi` date DEFAULT NULL COMMENT '出行日期',
  `chuxingfangshi` varchar(200) DEFAULT NULL COMMENT '出行方式',
  `qidian` varchar(200) DEFAULT NULL COMMENT '起点',
  `zhongdian` varchar(200) DEFAULT NULL COMMENT '终点',
  `beizhu` varchar(200) DEFAULT NULL COMMENT '备注',
  `jiashuzhanghao` varchar(200) DEFAULT NULL COMMENT '家属账号',
  `jiashuxingming` varchar(200) DEFAULT NULL COMMENT '家属姓名',
  `laorenxingming` varchar(200) DEFAULT NULL COMMENT '老人姓名',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8 COMMENT='出行信息';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chuxingxinxi`
--

LOCK TABLES `chuxingxinxi` WRITE;
/*!40000 ALTER TABLE `chuxingxinxi` DISABLE KEYS */;
INSERT INTO `chuxingxinxi` VALUES (61,'2024-03-16 14:07:14','2024-03-16','出行方式1','起点1','终点1','备注1','家属','家属姓名1','老人姓名1'),(62,'2024-03-16 14:07:14','2024-03-16','出行方式2','起点2','终点2','备注2','家属','家属姓名2','老人姓名2'),(63,'2024-03-16 14:07:14','2024-03-16','出行方式3','起点3','终点3','备注3','家属','家属姓名3','老人姓名3'),(64,'2024-03-16 14:07:14','2024-03-16','出行方式4','起点4','终点4','备注4','家属','家属姓名4','老人姓名4'),(65,'2024-03-16 14:07:14','2024-03-16','出行方式5','起点5','终点5','备注5','家属','家属姓名5','老人姓名5'),(66,'2024-03-16 14:07:14','2024-03-16','出行方式6','起点6','终点6','备注6','家属','家属姓名6','老人姓名6');
/*!40000 ALTER TABLE `chuxingxinxi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `config`
--

DROP TABLE IF EXISTS `config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `config` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(100) NOT NULL COMMENT '配置参数名称',
  `value` varchar(100) DEFAULT NULL COMMENT '配置参数值',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='配置文件';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `config`
--

LOCK TABLES `config` WRITE;
/*!40000 ALTER TABLE `config` DISABLE KEYS */;
INSERT INTO `config` VALUES (1,'swiper1','file/swiperPicture1.jpg'),(2,'swiper2','file/swiperPicture2.jpg'),(3,'swiper3','file/swiperPicture3.jpg');
/*!40000 ALTER TABLE `config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fangjianfenpei`
--

DROP TABLE IF EXISTS `fangjianfenpei`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fangjianfenpei` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `fangjianbianhao` varchar(200) NOT NULL COMMENT '房间编号',
  `fangjianlouceng` varchar(200) DEFAULT NULL COMMENT '房间楼层',
  `fangjianhao` varchar(200) DEFAULT NULL COMMENT '房间号',
  `ruzhuriqi` date NOT NULL COMMENT '入住日期',
  `laorenxingming` varchar(200) NOT NULL COMMENT '老人姓名',
  `xingbie` varchar(200) DEFAULT NULL COMMENT '性别',
  `nianling` varchar(200) DEFAULT NULL COMMENT '年龄',
  `jiashuzhanghao` varchar(200) DEFAULT NULL COMMENT '家属账号',
  `jiashuxingming` varchar(200) DEFAULT NULL COMMENT '家属姓名',
  PRIMARY KEY (`id`),
  UNIQUE KEY `fangjianbianhao` (`fangjianbianhao`)
) ENGINE=InnoDB AUTO_INCREMENT=167 DEFAULT CHARSET=utf8 COMMENT='房间分配';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fangjianfenpei`
--

LOCK TABLES `fangjianfenpei` WRITE;
/*!40000 ALTER TABLE `fangjianfenpei` DISABLE KEYS */;
INSERT INTO `fangjianfenpei` VALUES (161,'2024-03-16 14:07:14','1111111111','房间楼层1','房间号1','2024-03-16','老人姓名1','性别1','年龄1','家属账号1','家属姓名1'),(162,'2024-03-16 14:07:14','2222222222','房间楼层2','房间号2','2024-03-16','老人姓名2','性别2','年龄2','家属账号2','家属姓名2'),(163,'2024-03-16 14:07:14','3333333333','房间楼层3','房间号3','2024-03-16','老人姓名3','性别3','年龄3','家属账号3','家属姓名3'),(164,'2024-03-16 14:07:14','4444444444','房间楼层4','房间号4','2024-03-16','老人姓名4','性别4','年龄4','家属账号4','家属姓名4'),(165,'2024-03-16 14:07:14','5555555555','房间楼层5','房间号5','2024-03-16','老人姓名5','性别5','年龄5','家属账号5','家属姓名5'),(166,'2024-03-16 14:07:14','6666666666','房间楼层6','房间号6','2024-03-16','老人姓名6','性别6','年龄6','家属账号6','家属姓名6');
/*!40000 ALTER TABLE `fangjianfenpei` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hugong`
--

DROP TABLE IF EXISTS `hugong`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hugong` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `hugongzhanghao` varchar(200) NOT NULL COMMENT '护工账号',
  `hugongxingming` varchar(200) NOT NULL COMMENT '护工姓名',
  `touxiang` longtext COMMENT '头像',
  `xingbie` varchar(200) DEFAULT NULL COMMENT '性别',
  `lianxidianhua` varchar(200) DEFAULT NULL COMMENT '联系电话',
  `shenfenzhenghao` varchar(200) DEFAULT NULL COMMENT '身份证号',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hugongzhanghao` (`hugongzhanghao`)
) ENGINE=InnoDB AUTO_INCREMENT=177 DEFAULT CHARSET=utf8 COMMENT='护工';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hugong`
--

LOCK TABLES `hugong` WRITE;
/*!40000 ALTER TABLE `hugong` DISABLE KEYS */;
INSERT INTO `hugong` VALUES (171,'2024-03-16 14:07:14','护工账号1','护工姓名1','file/hugongTouxiang1.jpg,file/hugongTouxiang2.jpg,file/hugongTouxiang3.jpg','男','19819881111','441622200101010001'),(172,'2024-03-16 14:07:14','护工账号2','护工姓名2','file/hugongTouxiang2.jpg,file/hugongTouxiang3.jpg,file/hugongTouxiang4.jpg','男','19819881112','441622200202020002'),(173,'2024-03-16 14:07:14','护工账号3','护工姓名3','file/hugongTouxiang3.jpg,file/hugongTouxiang4.jpg,file/hugongTouxiang5.jpg','男','19819881113','441622200303030003'),(174,'2024-03-16 14:07:14','护工账号4','护工姓名4','file/hugongTouxiang4.jpg,file/hugongTouxiang5.jpg,file/hugongTouxiang6.jpg','男','19819881114','441622200404040004'),(175,'2024-03-16 14:07:14','护工账号5','护工姓名5','file/hugongTouxiang5.jpg,file/hugongTouxiang6.jpg,file/hugongTouxiang7.jpg','男','19819881115','441622200505050005'),(176,'2024-03-16 14:07:14','护工账号6','护工姓名6','file/hugongTouxiang6.jpg,file/hugongTouxiang7.jpg,file/hugongTouxiang8.jpg','男','19819881116','441622200606060006');
/*!40000 ALTER TABLE `hugong` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jiankangshuju`
--

DROP TABLE IF EXISTS `jiankangshuju`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jiankangshuju` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `laorenxingming` varchar(200) DEFAULT NULL COMMENT '老人姓名',
  `xingbie` varchar(200) DEFAULT NULL COMMENT '性别',
  `nianling` varchar(200) DEFAULT NULL COMMENT '年龄',
  `shengao` varchar(200) DEFAULT NULL COMMENT '身高',
  `tizhong` varchar(200) DEFAULT NULL COMMENT '体重',
  `jiashuzhanghao` varchar(200) DEFAULT NULL COMMENT '家属账号',
  `jiashuxingming` varchar(200) DEFAULT NULL COMMENT '家属姓名',
  `xueya` varchar(200) DEFAULT NULL COMMENT '血压',
  `xuetang` varchar(200) DEFAULT NULL COMMENT '血糖',
  `xinlv` varchar(200) DEFAULT NULL COMMENT '心率',
  `dengjishijian` datetime DEFAULT NULL COMMENT '登记时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1710598288080 DEFAULT CHARSET=utf8 COMMENT='健康数据';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jiankangshuju`
--

LOCK TABLES `jiankangshuju` WRITE;
/*!40000 ALTER TABLE `jiankangshuju` DISABLE KEYS */;
INSERT INTO `jiankangshuju` VALUES (81,'2024-03-16 14:07:14','老人姓名1','性别1','年龄1','身高1','体重1','家属账号1','家属姓名1','血压1','血糖1','心率1','2024-03-16 22:07:14'),(82,'2024-03-16 14:07:14','老人姓名2','性别2','年龄2','身高2','体重2','家属账号2','家属姓名2','血压2','血糖2','心率2','2024-03-16 22:07:14'),(83,'2024-03-16 14:07:14','老人姓名3','性别3','年龄3','身高3','体重3','家属账号3','家属姓名3','血压3','血糖3','心率3','2024-03-16 22:07:14'),(84,'2024-03-16 14:07:14','老人姓名4','性别4','年龄4','身高4','体重4','家属账号4','家属姓名4','血压4','血糖4','心率4','2024-03-16 22:07:14'),(85,'2024-03-16 14:07:14','老人姓名5','性别5','年龄5','身高5','体重5','家属账号5','家属姓名5','血压5','血糖5','心率5','2024-03-16 22:07:14'),(86,'2024-03-16 14:07:14','老人姓名6','性别6','年龄6','身高6','体重6','家属账号6','家属姓名6','血压6','血糖6','心率6','2024-03-16 22:07:14'),(1710598288079,'2024-03-16 14:11:27','老几','男','56','165','120','11','李局','56','56','56','2024-03-16 22:11:15');
/*!40000 ALTER TABLE `jiankangshuju` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jiashu`
--

DROP TABLE IF EXISTS `jiashu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jiashu` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `jiashuzhanghao` varchar(200) NOT NULL COMMENT '家属账号',
  `jiashumima` varchar(200) NOT NULL COMMENT '家属密码',
  `jiashuxingming` varchar(200) NOT NULL COMMENT '家属姓名',
  `touxiang` longtext COMMENT '头像',
  `xingbie` varchar(200) DEFAULT NULL COMMENT '性别',
  `shoujihaoma` varchar(200) DEFAULT NULL COMMENT '手机号码',
  PRIMARY KEY (`id`),
  UNIQUE KEY `jiashuzhanghao` (`jiashuzhanghao`)
) ENGINE=InnoDB AUTO_INCREMENT=1710598176919 DEFAULT CHARSET=utf8 COMMENT='家属';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jiashu`
--

LOCK TABLES `jiashu` WRITE;
/*!40000 ALTER TABLE `jiashu` DISABLE KEYS */;
INSERT INTO `jiashu` VALUES (31,'2024-03-16 14:07:14','家属账号1','123456','家属姓名1','file/jiashuTouxiang1.jpg','男','19819881111'),(32,'2024-03-16 14:07:14','家属账号2','123456','家属姓名2','file/jiashuTouxiang2.jpg','男','19819881112'),(33,'2024-03-16 14:07:14','家属账号3','123456','家属姓名3','file/jiashuTouxiang3.jpg','男','19819881113'),(34,'2024-03-16 14:07:14','家属账号4','123456','家属姓名4','file/jiashuTouxiang4.jpg','男','19819881114'),(35,'2024-03-16 14:07:14','家属账号5','123456','家属姓名5','file/jiashuTouxiang5.jpg','男','19819881115'),(36,'2024-03-16 14:07:14','家属账号6','123456','家属姓名6','file/jiashuTouxiang6.jpg','男','19819881116'),(1710598176918,'2024-03-16 14:09:36','11','11','李局','file/1710598173138.jpg','男','13201012011');
/*!40000 ALTER TABLE `jiashu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `laorenruzhudengji`
--

DROP TABLE IF EXISTS `laorenruzhudengji`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `laorenruzhudengji` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `ruzhuriqi` date NOT NULL COMMENT '入住日期',
  `laorenxingming` varchar(200) NOT NULL COMMENT '老人姓名',
  `xingbie` varchar(200) DEFAULT NULL COMMENT '性别',
  `nianling` varchar(200) DEFAULT NULL COMMENT '年龄',
  `jiashuzhanghao` varchar(200) DEFAULT NULL COMMENT '家属账号',
  `jiashuxingming` varchar(200) DEFAULT NULL COMMENT '家属姓名',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=157 DEFAULT CHARSET=utf8 COMMENT='老人入住登记';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `laorenruzhudengji`
--

LOCK TABLES `laorenruzhudengji` WRITE;
/*!40000 ALTER TABLE `laorenruzhudengji` DISABLE KEYS */;
INSERT INTO `laorenruzhudengji` VALUES (151,'2024-03-16 14:07:14','2024-03-16','老人姓名1','性别1','年龄1','家属账号1','家属姓名1'),(152,'2024-03-16 14:07:14','2024-03-16','老人姓名2','性别2','年龄2','家属账号2','家属姓名2'),(153,'2024-03-16 14:07:14','2024-03-16','老人姓名3','性别3','年龄3','家属账号3','家属姓名3'),(154,'2024-03-16 14:07:14','2024-03-16','老人姓名4','性别4','年龄4','家属账号4','家属姓名4'),(155,'2024-03-16 14:07:14','2024-03-16','老人姓名5','性别5','年龄5','家属账号5','家属姓名5'),(156,'2024-03-16 14:07:14','2024-03-16','老人姓名6','性别6','年龄6','家属账号6','家属姓名6');
/*!40000 ALTER TABLE `laorenruzhudengji` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `laorenxinxi`
--

DROP TABLE IF EXISTS `laorenxinxi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `laorenxinxi` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `laorenxingming` varchar(200) NOT NULL COMMENT '老人姓名',
  `xingbie` varchar(200) NOT NULL COMMENT '性别',
  `nianling` varchar(200) NOT NULL COMMENT '年龄',
  `shengao` varchar(200) DEFAULT NULL COMMENT '身高',
  `tizhong` varchar(200) DEFAULT NULL COMMENT '体重',
  `shoujihaoma` varchar(200) DEFAULT NULL COMMENT '手机号码',
  `shenfenzhenghao` varchar(200) DEFAULT NULL COMMENT '身份证号',
  `jiashuzhanghao` varchar(200) NOT NULL COMMENT '家属账号',
  `jiashuxingming` varchar(200) DEFAULT NULL COMMENT '家属姓名',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1710598234609 DEFAULT CHARSET=utf8 COMMENT='老人信息';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `laorenxinxi`
--

LOCK TABLES `laorenxinxi` WRITE;
/*!40000 ALTER TABLE `laorenxinxi` DISABLE KEYS */;
INSERT INTO `laorenxinxi` VALUES (71,'2024-03-16 14:07:14','老人姓名1','男','年龄1','身高1','体重1','19819881111','441622200101010001','家属账号1','家属姓名1'),(72,'2024-03-16 14:07:14','老人姓名2','男','年龄2','身高2','体重2','19819881112','441622200202020002','家属账号2','家属姓名2'),(73,'2024-03-16 14:07:14','老人姓名3','男','年龄3','身高3','体重3','19819881113','441622200303030003','家属账号3','家属姓名3'),(74,'2024-03-16 14:07:14','老人姓名4','男','年龄4','身高4','体重4','19819881114','441622200404040004','家属账号4','家属姓名4'),(75,'2024-03-16 14:07:14','老人姓名5','男','年龄5','身高5','体重5','19819881115','441622200505050005','家属账号5','家属姓名5'),(76,'2024-03-16 14:07:14','老人姓名6','男','年龄6','身高6','体重6','19819881116','441622200606060006','家属账号6','家属姓名6'),(1710598234608,'2024-03-16 14:10:33','老几','男','56','165','120','13201210100','441202000101201102','11','李局');
/*!40000 ALTER TABLE `laorenxinxi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `liuyanfankui`
--

DROP TABLE IF EXISTS `liuyanfankui`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `liuyanfankui` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `jiashuzhanghao` varchar(200) DEFAULT NULL COMMENT '家属账号',
  `jiashuxingming` varchar(200) DEFAULT NULL COMMENT '家属姓名',
  `fankuibiaoti` varchar(200) NOT NULL COMMENT '反馈标题',
  `fankuineirong` longtext NOT NULL COMMENT '反馈内容',
  `fankuishijian` datetime DEFAULT NULL COMMENT '反馈时间',
  `sfsh` varchar(200) DEFAULT NULL COMMENT '是否审核',
  `shhf` longtext COMMENT '回复内容',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8 COMMENT='留言反馈';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `liuyanfankui`
--

LOCK TABLES `liuyanfankui` WRITE;
/*!40000 ALTER TABLE `liuyanfankui` DISABLE KEYS */;
INSERT INTO `liuyanfankui` VALUES (41,'2024-03-16 14:07:14','家属账号1','家属姓名1','反馈标题1','反馈内容1','2024-03-16 22:07:14','是',''),(42,'2024-03-16 14:07:14','家属账号2','家属姓名2','反馈标题2','反馈内容2','2024-03-16 22:07:14','是',''),(43,'2024-03-16 14:07:14','家属账号3','家属姓名3','反馈标题3','反馈内容3','2024-03-16 22:07:14','是',''),(44,'2024-03-16 14:07:14','家属账号4','家属姓名4','反馈标题4','反馈内容4','2024-03-16 22:07:14','是',''),(45,'2024-03-16 14:07:14','家属账号5','家属姓名5','反馈标题5','反馈内容5','2024-03-16 22:07:14','是',''),(46,'2024-03-16 14:07:14','家属账号6','家属姓名6','反馈标题6','反馈内容6','2024-03-16 22:07:14','是','');
/*!40000 ALTER TABLE `liuyanfankui` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `meiricanyin`
--

DROP TABLE IF EXISTS `meiricanyin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `meiricanyin` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `riqi` date DEFAULT NULL COMMENT '日期',
  `canci` varchar(200) DEFAULT NULL COMMENT '餐次',
  `caipin` varchar(200) DEFAULT NULL COMMENT '菜品',
  `yingyangchengfen` varchar(200) DEFAULT NULL COMMENT '营养成分',
  `pengrenfangfa` varchar(200) DEFAULT NULL COMMENT '烹饪方法',
  `jiashuzhanghao` varchar(200) DEFAULT NULL COMMENT '家属账号',
  `jiashuxingming` varchar(200) DEFAULT NULL COMMENT '家属姓名',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8 COMMENT='每日餐饮';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `meiricanyin`
--

LOCK TABLES `meiricanyin` WRITE;
/*!40000 ALTER TABLE `meiricanyin` DISABLE KEYS */;
INSERT INTO `meiricanyin` VALUES (51,'2024-03-16 14:07:14','2024-03-16','早餐','菜品1','营养成分1','烹饪方法1','家属账号1','家属姓名1'),(52,'2024-03-16 14:07:14','2024-03-16','早餐','菜品2','营养成分2','烹饪方法2','家属账号2','家属姓名2'),(53,'2024-03-16 14:07:14','2024-03-16','早餐','菜品3','营养成分3','烹饪方法3','家属账号3','家属姓名3'),(54,'2024-03-16 14:07:14','2024-03-16','早餐','菜品4','营养成分4','烹饪方法4','家属账号4','家属姓名4'),(55,'2024-03-16 14:07:14','2024-03-16','早餐','菜品5','营养成分5','烹饪方法5','家属账号5','家属姓名5'),(56,'2024-03-16 14:07:14','2024-03-16','早餐','菜品6','营养成分6','烹饪方法6','家属账号6','家属姓名6');
/*!40000 ALTER TABLE `meiricanyin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu`
--

DROP TABLE IF EXISTS `menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menu` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `menujson` longtext COMMENT '菜单',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='菜单';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu`
--

LOCK TABLES `menu` WRITE;
/*!40000 ALTER TABLE `menu` DISABLE KEYS */;
INSERT INTO `menu` VALUES (1,'2024-03-16 14:07:14','[{\"backMenu\":[{\"child\":[{\"appFrontIcon\":\"cuIcon-explore\",\"buttons\":[\"新增\",\"查看\",\"修改\",\"删除\"],\"menu\":\"轮播图\",\"menuJump\":\"列表\",\"tableName\":\"config\"}],\"fontClass\":\"icon-common48\",\"menu\":\"轮播图管理\",\"unicode\":\"&#xef65;\"},{\"child\":[{\"appFrontIcon\":\"cuIcon-list\",\"buttons\":[\"新增\",\"查看\",\"修改\",\"删除\"],\"menu\":\"管理员\",\"menuJump\":\"列表\",\"tableName\":\"users\"}],\"fontClass\":\"icon-common35\",\"menu\":\"管理员管理\",\"unicode\":\"&#xee8c;\"},{\"child\":[{\"appFrontIcon\":\"cuIcon-brand\",\"buttons\":[\"新增\",\"查看\",\"修改\",\"删除\"],\"menu\":\"家属\",\"menuJump\":\"列表\",\"tableName\":\"jiashu\"},{\"appFrontIcon\":\"cuIcon-full\",\"buttons\":[\"新增\",\"查看\",\"修改\",\"删除\"],\"menu\":\"老人信息\",\"menuJump\":\"列表\",\"tableName\":\"laorenxinxi\"}],\"fontClass\":\"icon-user4\",\"menu\":\"用户管理\",\"unicode\":\"&#xef9a;\"},{\"child\":[{\"appFrontIcon\":\"cuIcon-flashlightopen\",\"buttons\":[\"查看\",\"修改\",\"删除\",\"审核\"],\"menu\":\"留言反馈\",\"menuJump\":\"列表\",\"tableName\":\"liuyanfankui\"}],\"fontClass\":\"icon-common18\",\"menu\":\"留言反馈管理\",\"unicode\":\"&#xedff;\"},{\"child\":[{\"appFrontIcon\":\"cuIcon-taxi\",\"buttons\":[\"新增\",\"查看\",\"修改\",\"删除\"],\"menu\":\"医疗服务\",\"menuJump\":\"列表\",\"tableName\":\"yiliaofuwu\"},{\"appFrontIcon\":\"cuIcon-newshot\",\"buttons\":[\"新增\",\"查看\",\"修改\",\"删除\"],\"menu\":\"出行陪护\",\"menuJump\":\"列表\",\"tableName\":\"chuxingpeihu\"},{\"appFrontIcon\":\"cuIcon-wenzi\",\"buttons\":[\"查看\",\"修改\",\"删除\"],\"menu\":\"预约医疗服务\",\"menuJump\":\"列表\",\"tableName\":\"yuyueyiliaofuwu\"},{\"appFrontIcon\":\"cuIcon-goods\",\"buttons\":[\"查看\",\"修改\",\"删除\"],\"menu\":\"预约出行陪护\",\"menuJump\":\"列表\",\"tableName\":\"yuyuechuxingpeihu\"}],\"fontClass\":\"icon-common24\",\"menu\":\"预约服务\",\"unicode\":\"&#xee07;\"},{\"child\":[{\"appFrontIcon\":\"cuIcon-flashlightopen\",\"buttons\":[\"查看\",\"修改\",\"删除\"],\"menu\":\"每日餐饮\",\"menuJump\":\"列表\",\"tableName\":\"meiricanyin\"},{\"appFrontIcon\":\"cuIcon-attentionfavor\",\"buttons\":[\"新增\",\"查看\",\"修改\",\"删除\"],\"menu\":\"出行信息\",\"menuJump\":\"列表\",\"tableName\":\"chuxingxinxi\"},{\"appFrontIcon\":\"cuIcon-goods\",\"buttons\":[\"查看\",\"修改\",\"删除\",\"审核\"],\"menu\":\"外出报备\",\"menuJump\":\"列表\",\"tableName\":\"waichubaobei\"},{\"appFrontIcon\":\"cuIcon-explore\",\"buttons\":[\"新增\",\"查看\",\"修改\",\"删除\"],\"menu\":\"休闲娱乐\",\"menuJump\":\"列表\",\"tableName\":\"xiuxianyule\"}],\"fontClass\":\"icon-common2\",\"menu\":\"生活服务\",\"unicode\":\"&#xeda4;\"},{\"child\":[{\"appFrontIcon\":\"cuIcon-phone\",\"buttons\":[\"新增\",\"查看\",\"修改\",\"删除\"],\"menu\":\"护工\",\"menuJump\":\"列表\",\"tableName\":\"hugong\"},{\"appFrontIcon\":\"cuIcon-paint\",\"buttons\":[\"新增\",\"查看\",\"修改\",\"删除\"],\"menu\":\"排班信息\",\"menuJump\":\"列表\",\"tableName\":\"paibanxinxi\"}],\"fontClass\":\"icon-common50\",\"menu\":\"护工管理\",\"unicode\":\"&#xef96;\"},{\"child\":[{\"appFrontIcon\":\"cuIcon-phone\",\"buttons\":[\"新增\",\"查看\",\"修改\",\"删除\"],\"menu\":\"健康数据\",\"menuJump\":\"列表\",\"tableName\":\"jiankangshuju\"},{\"appFrontIcon\":\"cuIcon-full\",\"buttons\":[\"新增\",\"查看\",\"修改\",\"删除\"],\"menu\":\"病例档案\",\"menuJump\":\"列表\",\"tableName\":\"binglidangan\"},{\"appFrontIcon\":\"cuIcon-pay\",\"buttons\":[\"新增\",\"查看\",\"修改\",\"删除\"],\"menu\":\"药品信息\",\"menuJump\":\"列表\",\"tableName\":\"yaopinxinxi\"}],\"fontClass\":\"icon-common14\",\"menu\":\"健康管理\",\"unicode\":\"&#xedfb;\"},{\"child\":[{\"appFrontIcon\":\"cuIcon-skin\",\"buttons\":[\"新增\",\"查看\",\"修改\",\"删除\"],\"menu\":\"老人入住登记\",\"menuJump\":\"列表\",\"tableName\":\"laorenruzhudengji\"},{\"appFrontIcon\":\"cuIcon-shop\",\"buttons\":[\"新增\",\"查看\",\"修改\",\"删除\"],\"menu\":\"房间分配\",\"menuJump\":\"列表\",\"tableName\":\"fangjianfenpei\"}],\"fontClass\":\"icon-common17\",\"menu\":\"入住管理\",\"unicode\":\"&#xedfe;\"}],\"frontMenu\":[{\"child\":[{\"appFrontIcon\":\"cuIcon-addressbook\",\"buttons\":[\"查看\"],\"menu\":\"休闲娱乐\",\"menuJump\":\"列表\",\"tableName\":\"xiuxianyule\"}],\"menu\":\"休闲娱乐管理\"},{\"child\":[{\"appFrontIcon\":\"cuIcon-shop\",\"buttons\":[\"查看\",\"预约\"],\"menu\":\"医疗服务\",\"menuJump\":\"列表\",\"tableName\":\"yiliaofuwu\"},{\"appFrontIcon\":\"cuIcon-attentionfavor\",\"buttons\":[\"查看\",\"预约\"],\"menu\":\"出行陪护\",\"menuJump\":\"列表\",\"tableName\":\"chuxingpeihu\"}],\"menu\":\"预约服务\"},{\"child\":[{\"appFrontIcon\":\"cuIcon-skin\",\"buttons\":[\"新增\",\"查看\"],\"menu\":\"留言反馈\",\"menuJump\":\"列表\",\"tableName\":\"liuyanfankui\"}],\"menu\":\"留言反馈管理\"}],\"hasBackLogin\":\"是\",\"hasBackRegister\":\"否\",\"hasFrontLogin\":\"否\",\"hasFrontRegister\":\"否\",\"roleName\":\"管理员\",\"tableName\":\"users\"},{\"backMenu\":[{\"child\":[{\"appFrontIcon\":\"cuIcon-full\",\"buttons\":[\"新增\",\"查看\",\"修改\",\"删除\"],\"menu\":\"老人信息\",\"menuJump\":\"列表\",\"tableName\":\"laorenxinxi\"}],\"fontClass\":\"icon-user4\",\"menu\":\"用户管理\",\"unicode\":\"&#xef9a;\"},{\"child\":[{\"appFrontIcon\":\"cuIcon-flashlightopen\",\"buttons\":[\"查看\",\"修改\",\"删除\"],\"menu\":\"留言反馈\",\"menuJump\":\"列表\",\"tableName\":\"liuyanfankui\"}],\"fontClass\":\"icon-common18\",\"menu\":\"留言反馈管理\",\"unicode\":\"&#xedff;\"},{\"child\":[{\"appFrontIcon\":\"cuIcon-wenzi\",\"buttons\":[\"查看\",\"修改\",\"删除\"],\"menu\":\"预约医疗服务\",\"menuJump\":\"列表\",\"tableName\":\"yuyueyiliaofuwu\"},{\"appFrontIcon\":\"cuIcon-goods\",\"buttons\":[\"查看\",\"修改\",\"删除\"],\"menu\":\"预约出行陪护\",\"menuJump\":\"列表\",\"tableName\":\"yuyuechuxingpeihu\"}],\"fontClass\":\"icon-common5\",\"menu\":\"预约服务\",\"unicode\":\"&#xedae;\"},{\"child\":[{\"appFrontIcon\":\"cuIcon-flashlightopen\",\"buttons\":[\"新增\",\"查看\",\"修改\",\"删除\"],\"menu\":\"每日餐饮\",\"menuJump\":\"列表\",\"tableName\":\"meiricanyin\"},{\"appFrontIcon\":\"cuIcon-attentionfavor\",\"buttons\":[\"查看\"],\"menu\":\"出行信息\",\"menuJump\":\"列表\",\"tableName\":\"chuxingxinxi\"},{\"appFrontIcon\":\"cuIcon-goods\",\"buttons\":[\"新增\",\"查看\",\"修改\",\"删除\"],\"menu\":\"外出报备\",\"menuJump\":\"列表\",\"tableName\":\"waichubaobei\"}],\"fontClass\":\"icon-common2\",\"menu\":\"生活服务\",\"unicode\":\"&#xeda4;\"},{\"child\":[{\"appFrontIcon\":\"cuIcon-phone\",\"buttons\":[\"新增\",\"查看\",\"修改\",\"删除\"],\"menu\":\"健康数据\",\"menuJump\":\"列表\",\"tableName\":\"jiankangshuju\"},{\"appFrontIcon\":\"cuIcon-full\",\"buttons\":[\"查看\"],\"menu\":\"病例档案\",\"menuJump\":\"列表\",\"tableName\":\"binglidangan\"},{\"appFrontIcon\":\"cuIcon-pay\",\"buttons\":[\"查看\"],\"menu\":\"药品信息\",\"menuJump\":\"列表\",\"tableName\":\"yaopinxinxi\"}],\"fontClass\":\"icon-common14\",\"menu\":\"健康管理\",\"unicode\":\"&#xedfb;\"},{\"child\":[{\"appFrontIcon\":\"cuIcon-skin\",\"buttons\":[\"查看\"],\"menu\":\"老人入住登记\",\"menuJump\":\"列表\",\"tableName\":\"laorenruzhudengji\"},{\"appFrontIcon\":\"cuIcon-shop\",\"buttons\":[\"查看\"],\"menu\":\"房间分配\",\"menuJump\":\"列表\",\"tableName\":\"fangjianfenpei\"}],\"fontClass\":\"icon-common17\",\"menu\":\"入住管理\",\"unicode\":\"&#xedfe;\"}],\"frontMenu\":[{\"child\":[{\"appFrontIcon\":\"cuIcon-addressbook\",\"buttons\":[\"查看\"],\"menu\":\"休闲娱乐\",\"menuJump\":\"列表\",\"tableName\":\"xiuxianyule\"}],\"menu\":\"休闲娱乐管理\"},{\"child\":[{\"appFrontIcon\":\"cuIcon-shop\",\"buttons\":[\"查看\",\"预约\"],\"menu\":\"医疗服务\",\"menuJump\":\"列表\",\"tableName\":\"yiliaofuwu\"},{\"appFrontIcon\":\"cuIcon-attentionfavor\",\"buttons\":[\"查看\",\"预约\"],\"menu\":\"出行陪护\",\"menuJump\":\"列表\",\"tableName\":\"chuxingpeihu\"}],\"menu\":\"预约服务\"},{\"child\":[{\"appFrontIcon\":\"cuIcon-skin\",\"buttons\":[\"新增\",\"查看\"],\"menu\":\"留言反馈\",\"menuJump\":\"列表\",\"tableName\":\"liuyanfankui\"}],\"menu\":\"留言反馈管理\"}],\"hasBackLogin\":\"否\",\"hasBackRegister\":\"否\",\"hasFrontLogin\":\"是\",\"hasFrontRegister\":\"是\",\"roleName\":\"家属\",\"tableName\":\"jiashu\"}]');
/*!40000 ALTER TABLE `menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `paibanxinxi`
--

DROP TABLE IF EXISTS `paibanxinxi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `paibanxinxi` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `hugongzhanghao` varchar(200) DEFAULT NULL COMMENT '护工账号',
  `hugongxingming` varchar(200) DEFAULT NULL COMMENT '护工姓名',
  `riqi` date DEFAULT NULL COMMENT '日期',
  `banci` varchar(200) DEFAULT NULL COMMENT '班次',
  `shangbanshijian` datetime DEFAULT NULL COMMENT '上班时间',
  `xiabanshijian` datetime DEFAULT NULL COMMENT '下班时间',
  `beizhu` varchar(200) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=187 DEFAULT CHARSET=utf8 COMMENT='排班信息';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paibanxinxi`
--

LOCK TABLES `paibanxinxi` WRITE;
/*!40000 ALTER TABLE `paibanxinxi` DISABLE KEYS */;
INSERT INTO `paibanxinxi` VALUES (181,'2024-03-16 14:07:14','护工账号1','护工姓名1','2024-03-16','早班','2024-03-16 22:07:14','2024-03-16 22:07:14','备注1'),(182,'2024-03-16 14:07:14','护工账号2','护工姓名2','2024-03-16','早班','2024-03-16 22:07:14','2024-03-16 22:07:14','备注2'),(183,'2024-03-16 14:07:14','护工账号3','护工姓名3','2024-03-16','早班','2024-03-16 22:07:14','2024-03-16 22:07:14','备注3'),(184,'2024-03-16 14:07:14','护工账号4','护工姓名4','2024-03-16','早班','2024-03-16 22:07:14','2024-03-16 22:07:14','备注4'),(185,'2024-03-16 14:07:14','护工账号5','护工姓名5','2024-03-16','早班','2024-03-16 22:07:14','2024-03-16 22:07:14','备注5'),(186,'2024-03-16 14:07:14','护工账号6','护工姓名6','2024-03-16','早班','2024-03-16 22:07:14','2024-03-16 22:07:14','备注6');
/*!40000 ALTER TABLE `paibanxinxi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `token`
--

DROP TABLE IF EXISTS `token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `token` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `userid` bigint(20) NOT NULL COMMENT '用户id',
  `username` varchar(100) NOT NULL COMMENT '用户名',
  `tablename` varchar(100) DEFAULT NULL COMMENT '表名',
  `role` varchar(100) DEFAULT NULL COMMENT '角色',
  `token` varchar(200) NOT NULL COMMENT '密码',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '新增时间',
  `expiratedtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '过期时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='token表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `token`
--

LOCK TABLES `token` WRITE;
/*!40000 ALTER TABLE `token` DISABLE KEYS */;
INSERT INTO `token` VALUES (1,1710598176918,'11','jiashu','家属','nadl268ahpecvh1vu1kv6r5bcijeu4cf','2024-03-16 14:09:40','2024-03-16 15:09:40'),(2,1,'admin','users','管理员','rz1i7d8ubhk9a7z9ubzhop477me49pgu','2024-03-16 14:10:53','2024-03-16 15:10:54');
/*!40000 ALTER TABLE `token` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `username` varchar(200) NOT NULL COMMENT '用户名',
  `password` varchar(200) NOT NULL COMMENT '密码',
  `role` varchar(200) DEFAULT NULL COMMENT '角色',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='管理员';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'2024-03-16 14:07:14','admin','admin','管理员');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `waichubaobei`
--

DROP TABLE IF EXISTS `waichubaobei`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `waichubaobei` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `jiashuzhanghao` varchar(200) DEFAULT NULL COMMENT '家属账号',
  `jiashuxingming` varchar(200) DEFAULT NULL COMMENT '家属姓名',
  `laorenxingming` varchar(200) DEFAULT NULL COMMENT '老人姓名',
  `waichuyuanyin` longtext NOT NULL COMMENT '外出原因',
  `waichushijian` datetime NOT NULL COMMENT '外出时间',
  `sfsh` varchar(200) DEFAULT NULL COMMENT '是否审核',
  `shhf` longtext COMMENT '回复内容',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=117 DEFAULT CHARSET=utf8 COMMENT='外出报备';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `waichubaobei`
--

LOCK TABLES `waichubaobei` WRITE;
/*!40000 ALTER TABLE `waichubaobei` DISABLE KEYS */;
INSERT INTO `waichubaobei` VALUES (111,'2024-03-16 14:07:14','家属账号1','家属姓名1','老人姓名1','外出原因1','2024-03-16 22:07:14','是',''),(112,'2024-03-16 14:07:14','家属账号2','家属姓名2','老人姓名2','外出原因2','2024-03-16 22:07:14','是',''),(113,'2024-03-16 14:07:14','家属账号3','家属姓名3','老人姓名3','外出原因3','2024-03-16 22:07:14','是',''),(114,'2024-03-16 14:07:14','家属账号4','家属姓名4','老人姓名4','外出原因4','2024-03-16 22:07:14','是',''),(115,'2024-03-16 14:07:14','家属账号5','家属姓名5','老人姓名5','外出原因5','2024-03-16 22:07:14','是',''),(116,'2024-03-16 14:07:14','家属账号6','家属姓名6','老人姓名6','外出原因6','2024-03-16 22:07:14','是','');
/*!40000 ALTER TABLE `waichubaobei` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `xiuxianyule`
--

DROP TABLE IF EXISTS `xiuxianyule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `xiuxianyule` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `huodongmingcheng` varchar(200) NOT NULL COMMENT '活动名称',
  `huodongtupian` longtext COMMENT '活动图片',
  `huodongshijian` datetime NOT NULL COMMENT '活动时间',
  `huodongdidian` varchar(200) NOT NULL COMMENT '活动地点',
  `huodongxiangqing` longtext COMMENT '活动详情',
  `fabushijian` datetime DEFAULT NULL COMMENT '发布时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=127 DEFAULT CHARSET=utf8 COMMENT='休闲娱乐';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xiuxianyule`
--

LOCK TABLES `xiuxianyule` WRITE;
/*!40000 ALTER TABLE `xiuxianyule` DISABLE KEYS */;
INSERT INTO `xiuxianyule` VALUES (121,'2024-03-16 14:07:14','活动名称1','file/xiuxianyuleHuodongtupian1.jpg,file/xiuxianyuleHuodongtupian2.jpg,file/xiuxianyuleHuodongtupian3.jpg','2024-03-16 22:07:14','活动地点1','活动详情1','2024-03-16 22:07:14'),(122,'2024-03-16 14:07:14','活动名称2','file/xiuxianyuleHuodongtupian2.jpg,file/xiuxianyuleHuodongtupian3.jpg,file/xiuxianyuleHuodongtupian4.jpg','2024-03-16 22:07:14','活动地点2','活动详情2','2024-03-16 22:07:14'),(123,'2024-03-16 14:07:14','活动名称3','file/xiuxianyuleHuodongtupian3.jpg,file/xiuxianyuleHuodongtupian4.jpg,file/xiuxianyuleHuodongtupian5.jpg','2024-03-16 22:07:14','活动地点3','活动详情3','2024-03-16 22:07:14'),(124,'2024-03-16 14:07:14','活动名称4','file/xiuxianyuleHuodongtupian4.jpg,file/xiuxianyuleHuodongtupian5.jpg,file/xiuxianyuleHuodongtupian6.jpg','2024-03-16 22:07:14','活动地点4','活动详情4','2024-03-16 22:07:14'),(125,'2024-03-16 14:07:14','活动名称5','file/xiuxianyuleHuodongtupian5.jpg,file/xiuxianyuleHuodongtupian6.jpg,file/xiuxianyuleHuodongtupian7.jpg','2024-03-16 22:07:14','活动地点5','活动详情5','2024-03-16 22:07:14'),(126,'2024-03-16 14:07:14','活动名称6','file/xiuxianyuleHuodongtupian6.jpg,file/xiuxianyuleHuodongtupian7.jpg,file/xiuxianyuleHuodongtupian8.jpg','2024-03-16 22:07:14','活动地点6','活动详情6','2024-03-16 22:07:14');
/*!40000 ALTER TABLE `xiuxianyule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `yaopinxinxi`
--

DROP TABLE IF EXISTS `yaopinxinxi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `yaopinxinxi` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `yaopinmingcheng` varchar(200) NOT NULL COMMENT '药品名称',
  `jixing` varchar(200) DEFAULT NULL COMMENT '剂型',
  `guige` varchar(200) NOT NULL COMMENT '规格',
  `baozhiqi` varchar(200) DEFAULT NULL COMMENT '保质期',
  `shengchanchangjia` varchar(200) DEFAULT NULL COMMENT '生产厂家',
  `yaopinshuoming` longtext COMMENT '药品说明',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=207 DEFAULT CHARSET=utf8 COMMENT='药品信息';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `yaopinxinxi`
--

LOCK TABLES `yaopinxinxi` WRITE;
/*!40000 ALTER TABLE `yaopinxinxi` DISABLE KEYS */;
INSERT INTO `yaopinxinxi` VALUES (201,'2024-03-16 14:07:14','药品名称1','颗粒','规格1','保质期1','生产厂家1','药品说明1'),(202,'2024-03-16 14:07:14','药品名称2','颗粒','规格2','保质期2','生产厂家2','药品说明2'),(203,'2024-03-16 14:07:14','药品名称3','颗粒','规格3','保质期3','生产厂家3','药品说明3'),(204,'2024-03-16 14:07:14','药品名称4','颗粒','规格4','保质期4','生产厂家4','药品说明4'),(205,'2024-03-16 14:07:14','药品名称5','颗粒','规格5','保质期5','生产厂家5','药品说明5'),(206,'2024-03-16 14:07:14','药品名称6','颗粒','规格6','保质期6','生产厂家6','药品说明6');
/*!40000 ALTER TABLE `yaopinxinxi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `yiliaofuwu`
--

DROP TABLE IF EXISTS `yiliaofuwu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `yiliaofuwu` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `yiyuanmingcheng` varchar(200) DEFAULT NULL COMMENT '医院名称',
  `yiliaoxiangmu` varchar(200) DEFAULT NULL COMMENT '医疗项目',
  `leixing` varchar(200) DEFAULT NULL COMMENT '类型',
  `xiangmujianjie` varchar(200) DEFAULT NULL COMMENT '项目简介',
  `xiangmuxiangqing` varchar(200) DEFAULT NULL COMMENT '项目详情',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=97 DEFAULT CHARSET=utf8 COMMENT='医疗服务';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `yiliaofuwu`
--

LOCK TABLES `yiliaofuwu` WRITE;
/*!40000 ALTER TABLE `yiliaofuwu` DISABLE KEYS */;
INSERT INTO `yiliaofuwu` VALUES (91,'2024-03-16 14:07:14','医院名称1','医疗项目1','类型1','项目简介1','项目详情1'),(92,'2024-03-16 14:07:14','医院名称2','医疗项目2','类型2','项目简介2','项目详情2'),(93,'2024-03-16 14:07:14','医院名称3','医疗项目3','类型3','项目简介3','项目详情3'),(94,'2024-03-16 14:07:14','医院名称4','医疗项目4','类型4','项目简介4','项目详情4'),(95,'2024-03-16 14:07:14','医院名称5','医疗项目5','类型5','项目简介5','项目详情5'),(96,'2024-03-16 14:07:14','医院名称6','医疗项目6','类型6','项目简介6','项目详情6');
/*!40000 ALTER TABLE `yiliaofuwu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `yuyuechuxingpeihu`
--

DROP TABLE IF EXISTS `yuyuechuxingpeihu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `yuyuechuxingpeihu` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `fuwuleixing` varchar(200) DEFAULT NULL COMMENT '服务类型',
  `fuwuneirong` longtext COMMENT '服务内容',
  `fabushijian` date DEFAULT NULL COMMENT '发布时间',
  `laorenxingming` varchar(200) DEFAULT NULL COMMENT '老人姓名',
  `jiashuzhanghao` varchar(200) DEFAULT NULL COMMENT '家属账号',
  `jiashuxingming` varchar(200) DEFAULT NULL COMMENT '家属姓名',
  `shoujihaoma` varchar(200) DEFAULT NULL COMMENT '手机号码',
  `yuyueshijian` datetime DEFAULT NULL COMMENT '预约时间',
  `peihuxuqiu` longtext COMMENT '陪护需求',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=147 DEFAULT CHARSET=utf8 COMMENT='预约出行陪护';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `yuyuechuxingpeihu`
--

LOCK TABLES `yuyuechuxingpeihu` WRITE;
/*!40000 ALTER TABLE `yuyuechuxingpeihu` DISABLE KEYS */;
INSERT INTO `yuyuechuxingpeihu` VALUES (141,'2024-03-16 14:07:14','服务类型1','服务内容1','2024-03-16','老人姓名1','家属账号1','家属姓名1','手机号码1','2024-03-16 22:07:14','陪护需求1'),(142,'2024-03-16 14:07:14','服务类型2','服务内容2','2024-03-16','老人姓名2','家属账号2','家属姓名2','手机号码2','2024-03-16 22:07:14','陪护需求2'),(143,'2024-03-16 14:07:14','服务类型3','服务内容3','2024-03-16','老人姓名3','家属账号3','家属姓名3','手机号码3','2024-03-16 22:07:14','陪护需求3'),(144,'2024-03-16 14:07:14','服务类型4','服务内容4','2024-03-16','老人姓名4','家属账号4','家属姓名4','手机号码4','2024-03-16 22:07:14','陪护需求4'),(145,'2024-03-16 14:07:14','服务类型5','服务内容5','2024-03-16','老人姓名5','家属账号5','家属姓名5','手机号码5','2024-03-16 22:07:14','陪护需求5'),(146,'2024-03-16 14:07:14','服务类型6','服务内容6','2024-03-16','老人姓名6','家属账号6','家属姓名6','手机号码6','2024-03-16 22:07:14','陪护需求6');
/*!40000 ALTER TABLE `yuyuechuxingpeihu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `yuyueyiliaofuwu`
--

DROP TABLE IF EXISTS `yuyueyiliaofuwu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `yuyueyiliaofuwu` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `yiyuanmingcheng` varchar(200) DEFAULT NULL COMMENT '医院名称',
  `yiliaoxiangmu` varchar(200) DEFAULT NULL COMMENT '医疗项目',
  `leixing` varchar(200) DEFAULT NULL COMMENT '类型',
  `xiangmujianjie` varchar(200) DEFAULT NULL COMMENT '项目简介',
  `xiangmuxiangqing` varchar(200) DEFAULT NULL COMMENT '项目详情',
  `laorenxingming` varchar(200) DEFAULT NULL COMMENT '老人姓名',
  `jiashuzhanghao` varchar(200) DEFAULT NULL COMMENT '家属账号',
  `jiashuxingming` varchar(200) DEFAULT NULL COMMENT '家属姓名',
  `yuyueshijian` date DEFAULT NULL COMMENT '预约时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=137 DEFAULT CHARSET=utf8 COMMENT='预约医疗服务';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `yuyueyiliaofuwu`
--

LOCK TABLES `yuyueyiliaofuwu` WRITE;
/*!40000 ALTER TABLE `yuyueyiliaofuwu` DISABLE KEYS */;
INSERT INTO `yuyueyiliaofuwu` VALUES (131,'2024-03-16 14:07:14','医院名称1','医疗项目1','类型1','项目简介1','项目详情1','老人姓名1','家属账号1','家属姓名1','2024-03-16'),(132,'2024-03-16 14:07:14','医院名称2','医疗项目2','类型2','项目简介2','项目详情2','老人姓名2','家属账号2','家属姓名2','2024-03-16'),(133,'2024-03-16 14:07:14','医院名称3','医疗项目3','类型3','项目简介3','项目详情3','老人姓名3','家属账号3','家属姓名3','2024-03-16'),(134,'2024-03-16 14:07:14','医院名称4','医疗项目4','类型4','项目简介4','项目详情4','老人姓名4','家属账号4','家属姓名4','2024-03-16'),(135,'2024-03-16 14:07:14','医院名称5','医疗项目5','类型5','项目简介5','项目详情5','老人姓名5','家属账号5','家属姓名5','2024-03-16'),(136,'2024-03-16 14:07:14','医院名称6','医疗项目6','类型6','项目简介6','项目详情6','老人姓名6','家属账号6','家属姓名6','2024-03-16');
/*!40000 ALTER TABLE `yuyueyiliaofuwu` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-03-17 12:16:26
